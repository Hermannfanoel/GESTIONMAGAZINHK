package mg.mandaniresaka.comptes;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.provider.MediaStore;
import android.text.InputType;
import android.text.TextUtils;
import android.util.Base64;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {
    static final String DEFAULT_URL = "http://192.168.1.24:8000";
    static final String HOOK =
        "(function(){if(window.__hk)return;window.__hk=1;"
        + "window.print=function(){Android.print();};"
        + "var oc=HTMLAnchorElement.prototype.click;"
        + "HTMLAnchorElement.prototype.click=function(){"
        + "if(this.download&&/^blob:/.test(this.href)){var n=this.download;"
        + "fetch(this.href).then(function(r){return r.blob();}).then(function(b){"
        + "var f=new FileReader();f.onload=function(){Android.save(n,b.type,f.result);};f.readAsDataURL(b);});"
        + "return;}"
        + "return oc.apply(this,arguments);};})();";

    WebView wv;
    SharedPreferences sp;
    ValueCallback<Uri[]> fileCb;
    boolean errorShown = false;
    final Handler handler = new Handler(Looper.getMainLooper());

    String url() { return sp.getString("url", DEFAULT_URL); }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("cfg", MODE_PRIVATE);
        getWindow().setStatusBarColor(Color.parseColor("#1F4E8C"));
        getWindow().setNavigationBarColor(Color.parseColor("#1F4E8C"));
        wv = new WebView(this);
        setContentView(wv);
        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        CookieManager.getInstance().setAcceptCookie(true);
        wv.addJavascriptInterface(new Bridge(), "Android");
        wv.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView v, String u, Bitmap f) {
                if (u != null && u.startsWith("http")) errorShown = false;
            }
            @Override
            public void onPageFinished(WebView v, String u) {
                v.evaluateJavascript(HOOK, null);
                CookieManager.getInstance().flush();
            }
            @Override
            public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                if (r.isForMainFrame()) showError();
            }
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                String sch = u.getScheme();
                String host = u.getHost();
                String base = Uri.parse(url()).getHost();
                if (host != null && host.equals(base)) return false;
                if ("blob".equals(sch) || "data".equals(sch) || "about".equals(sch)) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception x) { }
                return true;
            }
        });
        wv.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                try {
                    startActivityForResult(p.createIntent(), 1);
                } catch (Exception e) {
                    fileCb = null;
                    return false;
                }
                return true;
            }
        });
        wv.setDownloadListener((u, ua, cd, mime, len) -> {
            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u))); } catch (Exception e) { }
        });
        wv.loadUrl(url());
    }

    void showError() {
        errorShown = true;
        String h = "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'></head>"
            + "<body style='font-family:sans-serif;background:#0f1b2d;color:#fff;text-align:center;padding:40px 20px'>"
            + "<h2>Serveur injoignable</h2>"
            + "<p>Verifiez que le serveur est demarre (Termux : python server.py) et que la tablette est sur le meme Wi-Fi.</p>"
            + "<p style='opacity:.7'>Adresse : " + TextUtils.htmlEncode(url()) + "</p>"
            + "<p>Nouvel essai automatique toutes les 5 secondes.</p>"
            + "<p><button style='font-size:20px;padding:14px 28px;border:0;border-radius:10px;background:#2f6fd0;color:#fff' onclick='Android.retry()'>Reessayer</button></p>"
            + "<p><button style='font-size:16px;padding:10px 20px;border:0;border-radius:10px;background:#3a4a63;color:#fff' onclick='Android.changeUrl()'>Changer l'adresse du serveur</button></p>"
            + "</body></html>";
        wv.loadDataWithBaseURL(null, h, "text/html", "utf-8", null);
        handler.postDelayed(new Runnable() {
            @Override
            public void run() { if (errorShown) wv.loadUrl(url()); }
        }, 5000);
    }

    void askUrl() {
        final EditText e = new EditText(this);
        e.setText(url());
        e.setSingleLine(true);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        new AlertDialog.Builder(this)
            .setTitle("Adresse du serveur")
            .setMessage("Exemple : http://192.168.1.24:8000")
            .setView(e)
            .setPositiveButton("Enregistrer", (d, w) -> {
                String u = e.getText().toString().trim();
                if (!u.startsWith("http")) u = "http://" + u;
                sp.edit().putString("url", u).apply();
                wv.loadUrl(u);
            })
            .setNegativeButton("Annuler", null)
            .show();
    }

    void toast(final String m) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, m, Toast.LENGTH_LONG).show());
    }

    class Bridge {
        @JavascriptInterface
        public void retry() { runOnUiThread(() -> wv.loadUrl(url())); }

        @JavascriptInterface
        public void changeUrl() { runOnUiThread(() -> askUrl()); }

        @JavascriptInterface
        public void print() {
            runOnUiThread(() -> {
                PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                pm.print("Comptes fournisseurs", wv.createPrintDocumentAdapter("Comptes fournisseurs"),
                    new PrintAttributes.Builder().build());
            });
        }

        @JavascriptInterface
        public void save(String name, String mime, String dataUrl) {
            try {
                byte[] bytes = Base64.decode(dataUrl.substring(dataUrl.indexOf(',') + 1), Base64.DEFAULT);
                String safe = name.replaceAll("[\\\\/:*?\"<>|]", "_");
                String m = (mime == null || mime.isEmpty()) ? "application/octet-stream" : mime;
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues cv = new ContentValues();
                    cv.put(MediaStore.Downloads.DISPLAY_NAME, safe);
                    cv.put(MediaStore.Downloads.MIME_TYPE, m);
                    cv.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                    Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                    OutputStream o = getContentResolver().openOutputStream(u);
                    o.write(bytes);
                    o.close();
                    toast("Enregistre dans Telechargements : " + safe);
                } else {
                    File d = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                    File f = new File(d, safe);
                    FileOutputStream o = new FileOutputStream(f);
                    o.write(bytes);
                    o.close();
                    toast("Enregistre : " + f.getAbsolutePath());
                }
            } catch (Exception e) {
                toast("Enregistrement impossible.");
            }
        }
    }

    @Override
    protected void onActivityResult(int rq, int rs, Intent d) {
        if (rq == 1 && fileCb != null) {
            fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(rs, d));
            fileCb = null;
        } else {
            super.onActivityResult(rq, rs, d);
        }
    }

    @Override
    public void onBackPressed() {
        if (wv.canGoBack()) wv.goBack(); else moveTaskToBack(true);
    }

    @Override
    protected void onPause() {
        super.onPause();
        CookieManager.getInstance().flush();
        wv.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        wv.onResume();
    }
}
